<script setup lang="ts">
import { useTarget } from "@tmadmin/sdk";
const target = useTarget();
</script>
<template>
  <div class="tm-plugin-block" style="padding: 12px;">
    <strong>Сканер портов</strong>
    <p style="margin: 6px 0 0; font-size: 12px; opacity: 0.8;">Target: {{ target.host.value || "не выбран" }}</p>
  </div>
</template>
